"""
ProcessGraph — Backend Flask
Lê o CSV de execuções e serve dados sumarizados para o visualizador.
"""

import csv
import json
import math
import random
from collections import defaultdict
from datetime import datetime
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
CSV_PATH = "logs_execucoes.csv"
FMT = "%Y-%m-%d %H:%M:%S"

# ── LEITURA E CACHE ───────────────────────────────────────────────────────────

def ler_csv():
    rows = []
    with open(CSV_PATH, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            r["quantidade_tempo_ativo"]      = int(r["quantidade_tempo_ativo"])
            r["quantidade_tempo_total"]      = int(r["quantidade_tempo_total"])
            r["quantidade_copias"]           = int(r["quantidade_copias"])
            r["quantidade_colagens"]         = int(r["quantidade_colagens"])
            r["quantidade_teclas_digitadas"] = int(r["quantidade_teclas_digitadas"])
            r["quantidade_clicks"]           = int(r["quantidade_clicks"])
            try:
                r["_inicio"] = datetime.strptime(r["data_hora_inicio_exec"], FMT)
                r["_fim"]    = datetime.strptime(r["data_hora_fim_exec"],    FMT)
            except Exception:
                r["_inicio"] = r["_fim"] = None
            rows.append(r)
    return rows

_CACHE = None
def get_rows():
    global _CACHE
    if _CACHE is None:
        _CACHE = ler_csv()
    return _CACHE

# ── CATEGORIAS ────────────────────────────────────────────────────────────────

CATEGORIAS = {
    "Microsoft Excel":   "office",
    "Microsoft Word":    "office",
    "Bloco de Notas":    "office",
    "SAP Logon":         "erp",
    "Google Chrome":     "web",
    "Microsoft Outlook": "comm",
    "Microsoft Teams":   "comm",
    "Adobe Acrobat":     "doc",
}

CORES = {
    "office": "#00c2ff",
    "erp":    "#00ff9d",
    "web":    "#ff6b35",
    "comm":   "#a78bfa",
    "doc":    "#fbbf24",
}

# ── HELPERS ───────────────────────────────────────────────────────────────────

def fmt_tempo(segundos):
    h = segundos // 3600
    m = (segundos % 3600) // 60
    return f"{h}h {m:02d}m"

def node_id_programa(row):
    return row["nome_programa"].lower().replace(" ", "_")

def node_id_tela(row):
    prog = node_id_programa(row)
    tela = row["nome_tela_foco"].lower().replace(" ", "_").replace("/", "_").replace(".", "_")
    return f"{prog}__{tela}"

# ── SUMARIZAÇÃO ───────────────────────────────────────────────────────────────

def sumarizar(rows, granularidade="programa"):
    """
    granularidade: 'programa' | 'tela'
    Retorna dict com nodes e edges prontos para o frontend.
    """
    get_id   = node_id_programa if granularidade == "programa" else node_id_tela
    get_prog = lambda r: r["nome_programa"]
    get_label = (
        (lambda r: r["nome_programa"])
        if granularidade == "programa"
        else (lambda r: r["nome_tela_foco"])
    )
    get_sub = (
        (lambda r: "")
        if granularidade == "programa"
        else (lambda r: r["nome_programa"])
    )

    # acumuladores por nó
    node_acc = defaultdict(lambda: {
        "tempo_ativo": 0, "tempo_total": 0,
        "copias": 0, "colagens": 0,
        "teclas": 0, "clicks": 0,
        "dias": set(), "execucoes": 0,
        "users": set(),
        "label": "", "sublabel": "", "programa": "",
    })

    # transições: (src_id, tgt_id) → {count, data_transfers}
    trans_acc   = defaultdict(int)
    trans_users = defaultdict(set)
    copy_acc    = defaultdict(int)   # transferências de dados confirmadas
    copy_users  = defaultdict(set)

    # para detectar transferências de dados precisamos ordenar por funcionário+tempo
    # agrupamos por racf e ordenamos
    por_racf = defaultdict(list)
    for r in rows:
        por_racf[r["codigo_racf"]].append(r)

    for racf, execucoes in por_racf.items():
        # ordena por início
        execucoes_ord = sorted(
            [e for e in execucoes if e["_inicio"]],
            key=lambda x: x["_inicio"]
        )

        for i, row in enumerate(execucoes_ord):
            nid = get_id(row)

            # acumula métricas do nó
            acc = node_acc[nid]
            acc["tempo_ativo"]  += row["quantidade_tempo_ativo"]
            acc["tempo_total"]  += row["quantidade_tempo_total"]
            acc["copias"]       += row["quantidade_copias"]
            acc["colagens"]     += row["quantidade_colagens"]
            acc["teclas"]       += row["quantidade_teclas_digitadas"]
            acc["clicks"]       += row["quantidade_clicks"]
            acc["execucoes"]    += 1
            acc["label"]         = get_label(row)
            acc["sublabel"]      = get_sub(row)
            acc["programa"]      = get_prog(row)
            acc["users"].add(row["codigo_racf"])
            if row["_inicio"]:
                acc["dias"].add(row["_inicio"].date())

            # transição: linha atual → próxima linha do mesmo funcionário
            if i + 1 < len(execucoes_ord):
                prox = execucoes_ord[i + 1]
                src = nid
                tgt = get_id(prox)
                if src != tgt:
                    trans_acc[(src, tgt)] += 1
                    trans_users[(src, tgt)].add(row["codigo_racf"])

                    # detecta transferência de dados:
                    # cópia nesta tela E colagem na próxima
                    if row["quantidade_copias"] > 0 and prox["quantidade_colagens"] > 0:
                        copy_acc[(src, tgt)] += min(
                            row["quantidade_copias"],
                            prox["quantidade_colagens"]
                        )
                        copy_users[(src, tgt)].add(row["codigo_racf"])

    # monta lista de nós
    max_total = max((v["tempo_total"] for v in node_acc.values()), default=1)
    nodes = []
    for nid, acc in node_acc.items():
        prog = acc["programa"]
        cat  = CATEGORIAS.get(prog, "office")
        color = CORES.get(cat, "#00c2ff")
        tempo_total  = acc["tempo_total"]
        tempo_ativo  = acc["tempo_ativo"]
        active_pct   = round(tempo_ativo / tempo_total * 100) if tempo_total > 0 else 0
        intensity_pct = round(tempo_total / max_total * 100)
        nodes.append({
            "id":           nid,
            "label":        acc["label"],
            "sublabel":     acc["sublabel"],
            "category":     cat,
            "color":        color,
            "days":         len(acc["dias"]),
            "total":        fmt_tempo(tempo_total),
            "active":       fmt_tempo(tempo_ativo),
            "keys":         acc["teclas"],
            "clicks":       acc["clicks"],
            "copies":       acc["copias"],
            "pastes":       acc["colagens"],
            "execucoes":    acc["execucoes"],
            "users":        len(acc["users"]),
            "activePct":    active_pct,
            "intensityPct": intensity_pct,
            "tempo_total_raw": tempo_total,
        })

    # monta arestas de transição
    max_trans = max(trans_acc.values(), default=1)
    edges_trans = []
    for (src, tgt), cnt in trans_acc.items():
        if src in node_acc and tgt in node_acc:
            edges_trans.append({
                "source": src, "target": tgt,
                "count": cnt,
                "label": str(cnt),
                "weight": round(cnt / max_trans, 4),
                "users": len(trans_users[(src, tgt)]),
            })

    # monta arestas de cópia/cola
    max_copy = max(copy_acc.values(), default=1)
    edges_copy = []
    for (src, tgt), cnt in copy_acc.items():
        if src in node_acc and tgt in node_acc:
            edges_copy.append({
                "source": src, "target": tgt,
                "count": cnt,
                "label": str(cnt),
                "weight": round(cnt / max_copy, 4),
                "users": len(copy_users[(src, tgt)]),
            })

    return {
        "nodes":       nodes,
        "edges_trans": edges_trans,
        "edges_copy":  edges_copy,
    }

# ── LAYOUT ────────────────────────────────────────────────────────────────────
# Trabalha em pixels reais para garantir separação física entre nós.
# Recebe o tamanho do canvas (W, H) para escalar margens e distâncias
# proporcionalmente, independente de quantos nós existam.

NODE_W_PX = 148   # largura do nó em px (deve bater com o frontend)
NODE_H_PX =  54   # altura do nó em px

def calcular_layout(nodes, edges_trans, canvas_w=1280, canvas_h=700):
    """
    Layout baseado em força com anti-sobreposição garantida.

    Estratégia em 3 fases:
      1. Posição inicial em grade espaçada — garante separação mínima desde o início
      2. Simulação de força com resfriamento — organiza por conexões
      3. Passe final de descompressão — elimina qualquer sobreposição residual
    """
    if not nodes:
        return {}

    ids = [n["id"] for n in nodes]
    n   = len(ids)
    idx = {nid: i for i, nid in enumerate(ids)}

    # ── dimensões e margens ─────────────────────────────────────────────────
    PAD_X = max(NODE_W_PX * 0.75, canvas_w * 0.055)
    PAD_Y = max(NODE_H_PX * 1.4,  canvas_h * 0.075)

    # separação mínima entre centros (com folga de 20% além do tamanho do nó)
    MIN_DX   = NODE_W_PX * 1.7
    MIN_DY   = NODE_H_PX * 2.4
    MIN_DIST = math.sqrt(MIN_DX**2 + MIN_DY**2)

    usable_w = canvas_w - 2 * PAD_X
    usable_h = canvas_h - 2 * PAD_Y
    cx, cy   = canvas_w / 2, canvas_h / 2

    # ── FASE 1: posição inicial em grade espaçada ───────────────────────────
    # Escolhe colunas para minimizar canvas virtual total respeitando MIN_DX/MIN_DY
    best = None
    for c in range(1, n + 1):
        r = math.ceil(n / c)
        w = PAD_X * 2 + c * MIN_DX
        h = PAD_Y * 2 + r * MIN_DY
        area = max(w, canvas_w) * max(h, canvas_h)
        if best is None or area < best[0]:
            best = (area, c, r, w, h)
    _, cols, rows_cnt, need_w, need_h = best

    # espaçamento uniforme dentro do canvas virtual
    virt_w = max(canvas_w, need_w)
    virt_h = max(canvas_h, need_h)
    vcx, vcy = virt_w / 2, virt_h / 2

    step_x = (virt_w - 2 * PAD_X) / max(cols, 1)
    step_y = (virt_h - 2 * PAD_Y) / max(rows_cnt, 1)

    # centraliza a grade
    grid_w = (cols - 1)     * step_x
    grid_h = (rows_cnt - 1) * step_y
    orig_x = vcx - grid_w / 2
    orig_y = vcy - grid_h / 2

    pos = []
    for i in range(n):
        c = i % cols
        r = i // cols
        jitter_x = random.uniform(-MIN_DX * 0.06, MIN_DX * 0.06)
        jitter_y = random.uniform(-MIN_DY * 0.06, MIN_DY * 0.06)
        pos.append([
            max(PAD_X, min(canvas_w - PAD_X, orig_x + c * step_x + jitter_x)),
            max(PAD_Y, min(canvas_h - PAD_Y, orig_y + r * step_y + jitter_y)),
        ])

    # ── FASE 2: simulação de força com resfriamento ─────────────────────────
    area  = usable_w * usable_h
    # repulsão escala com área/nós² — mais nós = repulsão mais concentrada
    K_rep = (area / (n * n)) * 0.4
    # separação de emergência proporcional ao tamanho do nó
    K_sep = MIN_DIST * 4.0
    # atração por arestas — cresce com peso mas nunca puxa para sobreposição
    K_att = 0.012
    # gravidade para o centro — evita deriva
    K_cen = 0.003

    ITER = 220
    vel  = [[0.0, 0.0] for _ in range(n)]
    DAMP = 0.68   # amortecimento alto = assenta mais rápido

    for it in range(ITER):
        # temperatura desce de 1.0 a 0.1 em curva suave
        temp = 0.1 + 0.9 * (1.0 - it / ITER) ** 2.0
        forces = [[0.0, 0.0] for _ in range(n)]

        # repulsão entre pares
        for i in range(n):
            for j in range(i + 1, n):
                dx = pos[i][0] - pos[j][0]
                dy = pos[i][1] - pos[j][1]
                dist = math.sqrt(dx*dx + dy*dy) + 1e-9
                ux, uy = dx / dist, dy / dist

                # repulsão geral suave
                f = K_rep / dist * temp

                # força de separação extra quando há sobreposição real
                if dist < MIN_DIST:
                    overlap = (MIN_DIST - dist) / MIN_DIST  # 0..1
                    # quadrática: suave perto do limite, forte no centro
                    f += K_sep * overlap * overlap

                forces[i][0] += f * ux;  forces[i][1] += f * uy
                forces[j][0] -= f * ux;  forces[j][1] -= f * uy

        # atração por arestas (só além da distância mínima)
        for edge in edges_trans:
            si = idx.get(edge["source"])
            ti = idx.get(edge["target"])
            if si is None or ti is None:
                continue
            w  = edge["weight"]
            dx = pos[ti][0] - pos[si][0]
            dy = pos[ti][1] - pos[si][1]
            dist = math.sqrt(dx*dx + dy*dy) + 1e-9
            if dist > MIN_DIST:
                f = K_att * w * (dist - MIN_DIST) * temp
                ux, uy = dx / dist, dy / dist
                forces[si][0] += f * ux;  forces[si][1] += f * uy
                forces[ti][0] -= f * ux;  forces[ti][1] -= f * uy

        # gravidade suave para o centro virtual
        for i in range(n):
            forces[i][0] += K_cen * (vcx - pos[i][0]) * temp
            forces[i][1] += K_cen * (vcy - pos[i][1]) * temp

        # integração com velocidade amortecida (clamp no canvas virtual)
        for i in range(n):
            vel[i][0] = (vel[i][0] + forces[i][0]) * DAMP
            vel[i][1] = (vel[i][1] + forces[i][1]) * DAMP
            pos[i][0] = max(PAD_X, min(virt_w - PAD_X, pos[i][0] + vel[i][0]))
            pos[i][1] = max(PAD_Y, min(virt_h - PAD_Y, pos[i][1] + vel[i][1]))

        # nas últimas 40% das iterações: micro-descompressão após cada passo
        if it >= ITER * 0.6:
            for i in range(n):
                for j in range(i + 1, n):
                    dx = pos[i][0] - pos[j][0]
                    dy = pos[i][1] - pos[j][1]
                    dist = math.sqrt(dx*dx + dy*dy) + 1e-9
                    if dist < MIN_DIST:
                        push = (MIN_DIST - dist) / 2 * 0.9
                        ux, uy = dx / dist, dy / dist
                        pos[i][0] = max(PAD_X, pos[i][0] + ux * push)
                        pos[i][1] = max(PAD_Y, pos[i][1] + uy * push)
                        pos[j][0] = max(PAD_X, pos[j][0] - ux * push)
                        pos[j][1] = max(PAD_Y, pos[j][1] - uy * push)

    # ── FASE 3: descompressão AABB — separação por eixo para retângulos ────
    # Opera diretamente nas sobreposições de bounding box, mais eficiente
    # para nós retangulares do que distância euclidiana.
    for _ in range(600):
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                ox = abs(pos[i][0] - pos[j][0])  # distância atual entre centros
                oy = abs(pos[i][1] - pos[j][1])
                # sobreposição real nas duas dimensões (AABB)
                overlap_x = MIN_DX - ox
                overlap_y = MIN_DY - oy
                if overlap_x > 0 and overlap_y > 0:
                    # resolve pelo eixo de menor sobreposição (empurra menos)
                    if overlap_x <= overlap_y:
                        push = overlap_x / 2 + 1.0
                        sx = 1 if pos[i][0] >= pos[j][0] else -1
                        pos[i][0] += sx * push
                        pos[j][0] -= sx * push
                    else:
                        push = overlap_y / 2 + 1.0
                        sy = 1 if pos[i][1] >= pos[j][1] else -1
                        pos[i][1] += sy * push
                        pos[j][1] -= sy * push
                    moved = True
        if not moved:
            break

    # garante coordenadas positivas e atualiza canvas virtual ao tamanho real
    for i in range(n):
        pos[i][0] = max(PAD_X, pos[i][0])
        pos[i][1] = max(PAD_Y, pos[i][1])
    virt_w = max(virt_w, max(p[0] for p in pos) + PAD_X)
    virt_h = max(virt_h, max(p[1] for p in pos) + PAD_Y)

    # normaliza para 0..1 relativo ao canvas virtual
    return {
        "positions": {
            nid: {
                "x": round(pos[idx[nid]][0] / virt_w, 4),
                "y": round(pos[idx[nid]][1] / virt_h, 4),
            }
            for nid in ids
        },
        "virt_w": round(virt_w),
        "virt_h": round(virt_h),
    }

# ── ROTAS ─────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/funcionarios")
def api_funcionarios():
    rows = get_rows()
    racfs = sorted(set(r["codigo_racf"] for r in rows))
    return jsonify(racfs)

@app.route("/api/periodos")
def api_periodos():
    rows = get_rows()
    datas = [r["_inicio"].date() for r in rows if r["_inicio"]]
    if not datas:
        return jsonify([])
    min_d, max_d = min(datas), max(datas)
    return jsonify({"min": str(min_d), "max": str(max_d)})

@app.route("/api/grafo")
def api_grafo():
    rows = get_rows()

    # filtros via query string
    racf         = request.args.get("racf", "")          # "" = todos
    granularidade = request.args.get("gran", "programa")  # programa | tela
    data_ini     = request.args.get("data_ini", "")
    data_fim     = request.args.get("data_fim", "")

    # aplica filtros
    filtrado = rows
    if racf:
        filtrado = [r for r in filtrado if r["codigo_racf"] == racf]
    if data_ini:
        try:
            di = datetime.strptime(data_ini, "%Y-%m-%d").date()
            filtrado = [r for r in filtrado if r["_inicio"] and r["_inicio"].date() >= di]
        except ValueError:
            pass
    if data_fim:
        try:
            df = datetime.strptime(data_fim, "%Y-%m-%d").date()
            filtrado = [r for r in filtrado if r["_inicio"] and r["_inicio"].date() <= df]
        except ValueError:
            pass

    canvas_w = int(request.args.get("cw", 1280))
    canvas_h = int(request.args.get("ch", 700))

    data   = sumarizar(filtrado, granularidade)
    layout = calcular_layout(data["nodes"], data["edges_trans"], canvas_w, canvas_h)

    positions = layout["positions"]
    data["virt_w"] = layout["virt_w"]
    data["virt_h"] = layout["virt_h"]
    for node in data["nodes"]:
        pos = positions.get(node["id"], {"x": 0.5, "y": 0.5})
        node["x"] = pos["x"]
        node["y"] = pos["y"]

    return jsonify(data)

# ── RUN ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("✓ ProcessGraph rodando em http://localhost:5000")
    app.run(debug=True, port=5000)
