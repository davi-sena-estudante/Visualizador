# ProcessGraph — Guia de Uso

## Estrutura

```
processgraph/
├── app.py                  ← Backend Flask (parser + API)
├── logs_execucoes.csv      ← Base de dados
├── templates/
│   └── index.html          ← Frontend (grafo SVG)
└── README.md
```

## Instalação

```bash
pip install flask
```

## Rodar

```bash
cd processgraph
python app.py
```

Abra no browser: **http://localhost:5000**

## API

| Rota | Parâmetros | Descrição |
|---|---|---|
| `GET /api/funcionarios` | — | Lista de RACFs |
| `GET /api/periodos` | — | Data mínima e máxima no CSV |
| `GET /api/grafo` | `racf`, `gran`, `data_ini`, `data_fim` | Nós + arestas sumarizados |

### Parâmetros de `/api/grafo`

- `racf` — código do funcionário (vazio = todos)
- `gran` — `programa` ou `tela`
- `data_ini` / `data_fim` — formato `YYYY-MM-DD`

## Trocar o CSV

Substitua `logs_execucoes.csv` por seu arquivo real.
As colunas obrigatórias são:

```
execucao_id, codigo_racf, nome_programa, nome_tela_foco,
data_hora_inicio_exec, data_hora_fim_exec,
quantidade_tempo_ativo, quantidade_tempo_total,
quantidade_copias, quantidade_colagens,
quantidade_teclas_digitadas, quantidade_clicks
```
